using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ScoreManager : MonoBehaviour
{
    public int currentFrame;
    public int currentFrameScore;
    public int totalScore;

    
}
